import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "sims.db")


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


SCHEMA = """
CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    sku TEXT UNIQUE NOT NULL,
    category TEXT,
    stock INTEGER DEFAULT 0,
    price REAL DEFAULT 0,
    low_threshold INTEGER DEFAULT 20,
    critical_threshold INTEGER DEFAULT 10
);

CREATE TABLE IF NOT EXISTS suppliers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    contact TEXT,
    category TEXT,
    lead_time_days INTEGER,
    rating REAL,
    status TEXT DEFAULT 'Active'
);

CREATE TABLE IF NOT EXISTS sales (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_code TEXT UNIQUE NOT NULL,
    product TEXT,
    customer TEXT,
    qty INTEGER,
    revenue REAL,
    sale_date TEXT,
    status TEXT DEFAULT 'Completed'
);
"""

PRODUCTS_SEED = [
    ("Laptop Pro X1", "LP-001", "Electronics", 145, 499.99, 30, 15),
    ("Wireless Earbuds", "WE-042", "Electronics", 289, 99.99, 30, 15),
    ("Smart Watch", "SW-018", "Electronics", 167, 249.99, 30, 15),
    ("USB-C Cable", "UC-103", "Accessories", 423, 19.99, 30, 15),
    ("Phone Case", "PC-222", "Accessories", 312, 19.99, 30, 15),
    ("HDMI Cable", "HC-007", "Accessories", 5, 14.99, 20, 10),
    ("AA Batteries (8pk)", "AB-311", "Consumables", 12, 8.99, 30, 15),
    ("Notebook A5", "NB-055", "Stationery", 8, 5.49, 25, 12),
    ("USB Flash Drive 64GB", "FD-064", "Electronics", 15, 22.99, 40, 20),
    ("Bluetooth Speaker", "BS-089", "Electronics", 78, 79.99, 30, 15),
    ("Mechanical Keyboard", "MK-147", "Electronics", 54, 149.99, 30, 15),
    ("Webcam HD 1080p", "WC-210", "Electronics", 32, 69.99, 30, 15),
]

SUPPLIERS_SEED = [
    ("TechCore Distributors", "sales@techcore.com", "Electronics", 3, 4.8, "Active"),
    ("GlobalParts Ltd.", "orders@globalparts.io", "Accessories", 5, 4.5, "Active"),
    ("ConsumablePro", "b2b@consumpro.com", "Consumables", 2, 4.9, "Active"),
    ("OfficeBridge Supply", "supply@officebridge.com", "Stationery", 4, 3.9, "Review"),
    ("QuantumElectronics", "wholesale@qelec.net", "Electronics", 7, 4.6, "Active"),
    ("FastShip Logistics", "ops@fastship.co", "All Categories", 1, 4.7, "Active"),
    ("SilkRoute Imports", "import@silkroute.com", "Mixed", 14, 3.6, "Inactive"),
]

SALES_SEED = [
    ("ORD-9821", "Laptop Pro X1", "Infosys Ltd.", 5, 2499.95, "2025-10-31", "Completed"),
    ("ORD-9820", "Wireless Earbuds", "Retail Hub", 20, 1999.80, "2025-10-30", "Completed"),
    ("ORD-9819", "Smart Watch", "GadgetZone", 8, 1999.92, "2025-10-30", "Shipped"),
    ("ORD-9818", "Bluetooth Speaker", "SoundWorld", 15, 1199.85, "2025-10-29", "Shipped"),
    ("ORD-9817", "USB-C Cable", "TechBazar", 100, 1999.00, "2025-10-29", "Completed"),
    ("ORD-9816", "Mechanical Keyboard", "DevSetup Co.", 3, 449.97, "2025-10-28", "Completed"),
    ("ORD-9815", "Webcam HD 1080p", "StartupHub", 10, 699.90, "2025-10-28", "Pending"),
    ("ORD-9814", "Phone Case", "MobleKing", 50, 999.50, "2025-10-27", "Completed"),
    ("ORD-9813", "USB Flash Drive 64GB", "DataSafe Inc.", 25, 574.75, "2025-10-27", "Shipped"),
]


def init_db(force=False):
    fresh = force or not os.path.exists(DB_PATH)
    conn = get_db()
    conn.executescript(SCHEMA)

    if fresh:
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM products")
        if cur.fetchone()[0] == 0:
            conn.executemany(
                "INSERT INTO products (name, sku, category, stock, price, low_threshold, critical_threshold) VALUES (?,?,?,?,?,?,?)",
                PRODUCTS_SEED,
            )
        cur.execute("SELECT COUNT(*) FROM suppliers")
        if cur.fetchone()[0] == 0:
            conn.executemany(
                "INSERT INTO suppliers (name, contact, category, lead_time_days, rating, status) VALUES (?,?,?,?,?,?)",
                SUPPLIERS_SEED,
            )
        cur.execute("SELECT COUNT(*) FROM sales")
        if cur.fetchone()[0] == 0:
            conn.executemany(
                "INSERT INTO sales (order_code, product, customer, qty, revenue, sale_date, status) VALUES (?,?,?,?,?,?,?)",
                SALES_SEED,
            )
        conn.commit()
    conn.close()
