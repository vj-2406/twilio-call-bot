# SIMS — Smart Inventory Management (Flask + REST API)

A Flask rebuild of your SIMS dashboard. Products, suppliers, and sales are
stored in a SQLite database and served through a JSON REST API. The
dashboard, low-stock alerts, and charts are all calculated live from the
database instead of being hardcoded in HTML.

## Run it locally

```bash
pip install -r requirements.txt
python app.py
```

Then open http://localhost:5000

The database (`sims.db`) is created automatically on first run, seeded with
the same sample data as your original HTML mockup.

## REST API

| Method | Endpoint              | Description                  |
|--------|------------------------|-------------------------------|
| GET    | /api/products           | List all products            |
| POST   | /api/products           | Create a product              |
| PUT    | /api/products/<id>      | Update a product              |
| DELETE | /api/products/<id>      | Delete a product              |
| GET    | /api/suppliers          | List all suppliers           |
| POST   | /api/suppliers          | Create a supplier             |
| PUT    | /api/suppliers/<id>     | Update a supplier             |
| DELETE | /api/suppliers/<id>     | Delete a supplier             |
| GET    | /api/sales              | List all sales orders        |
| POST   | /api/sales              | Create a sales order          |
| PUT    | /api/sales/<id>         | Update a sales order          |
| DELETE | /api/sales/<id>         | Delete a sales order          |
| GET    | /api/dashboard          | Aggregated dashboard metrics  |

Example:
```bash
curl -X POST http://localhost:5000/api/products \
  -H "Content-Type: application/json" \
  -d '{"name":"Mouse Pad","sku":"MP-001","category":"Accessories","stock":50,"price":9.99}'
```

## Deploy it live — Render (free, recommended)

1. Create a GitHub repo and push this folder to it (see "Push to GitHub" below).
2. Go to https://render.com, sign up/log in (free), click **New +** → **Blueprint**.
3. Connect your GitHub repo. Render will detect `render.yaml` automatically
   and configure the build/start commands for you.
4. Click **Apply** / **Create**. Render builds and deploys it — you'll get a
   live URL like `https://sims-inventory.onrender.com` in a couple of minutes.

   If you'd rather not use the Blueprint, you can do it manually:
   - New + → Web Service → connect your repo
   - Build command: `pip install -r requirements.txt`
   - Start command: `gunicorn app:app`
   - Plan: Free

**Note on the free tier:** Render's free web services spin down after 15
minutes of inactivity and spin back up on the next request (takes ~30-50
seconds to "wake up"). Also, the SQLite file resets on redeploys/restarts
on the free plan since there's no persistent disk — fine for a demo, but if
you want data to survive restarts, attach a Render persistent disk (small
paid add-on) or swap to Render's free PostgreSQL.

## Deploy it live — Railway (alternative)

1. Push this repo to GitHub.
2. Go to https://railway.app → New Project → Deploy from GitHub repo.
3. Railway auto-detects Python + the `Procfile` and deploys it.
4. Generate a public domain under Settings → Networking.

## Deploy it live — PythonAnywhere (alternative, simplest for SQLite persistence)

1. Sign up at https://www.pythonanywhere.com (free tier).
2. Upload this folder (or `git clone` your repo) via the Files/Bash console.
3. Web tab → Add a new web app → Manual configuration → Python 3.10 → Flask.
4. Point the WSGI file's `app` import at this `app.py`.
5. Reload — your app is live at `yourusername.pythonanywhere.com`. PythonAnywhere
   keeps a real persistent filesystem, so `sims.db` won't get wiped between requests.

## Push to GitHub

```bash
cd sims
git init
git add .
git commit -m "SIMS Flask app"
git branch -M main
git remote add origin https://github.com/<you>/sims-inventory.git
git push -u origin main
```
