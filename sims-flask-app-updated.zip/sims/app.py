from flask import Flask, jsonify, request, render_template
from database import get_db, init_db
import os

app = Flask(__name__)
init_db()


def stock_status(stock, low, critical):
    if stock <= critical:
        return "Critical"
    if stock <= low:
        return "Low Stock"
    return "In Stock"


def row_to_product(r):
    d = dict(r)
    d["status"] = stock_status(d["stock"], d["low_threshold"], d["critical_threshold"])
    return d


# ---------- Page routes ----------

@app.route("/")
def index():
    return render_template("index.html")


# ---------- Dashboard summary ----------

@app.route("/api/dashboard")
def api_dashboard():
    conn = get_db()
    products = [row_to_product(r) for r in conn.execute("SELECT * FROM products")]
    sales = [dict(r) for r in conn.execute("SELECT * FROM sales")]
    conn.close()

    total_products = len(products)
    total_stock_value = sum(p["stock"] * p["price"] for p in products)
    total_revenue = sum(s["revenue"] for s in sales)
    low_stock_items = [p for p in products if p["status"] in ("Low Stock", "Critical")]

    return jsonify({
        "total_products": total_products,
        "total_stock_value": round(total_stock_value, 2),
        "total_revenue": round(total_revenue, 2),
        "low_stock_count": len(low_stock_items),
        "low_stock_items": low_stock_items,
        "top_products": sorted(products, key=lambda p: p["stock"], reverse=True)[:5],
    })


# ---------- Products CRUD ----------

@app.route("/api/products", methods=["GET"])
def get_products():
    conn = get_db()
    rows = conn.execute("SELECT * FROM products ORDER BY id").fetchall()
    conn.close()
    return jsonify([row_to_product(r) for r in rows])


@app.route("/api/products", methods=["POST"])
def add_product():
    data = request.get_json(force=True)
    conn = get_db()
    cur = conn.execute(
        "INSERT INTO products (name, sku, category, stock, price, low_threshold, critical_threshold) VALUES (?,?,?,?,?,?,?)",
        (
            data.get("name"),
            data.get("sku"),
            data.get("category"),
            data.get("stock", 0),
            data.get("price", 0),
            data.get("low_threshold", 20),
            data.get("critical_threshold", 10),
        ),
    )
    conn.commit()
    new_id = cur.lastrowid
    row = conn.execute("SELECT * FROM products WHERE id=?", (new_id,)).fetchone()
    conn.close()
    return jsonify(row_to_product(row)), 201


@app.route("/api/products/<int:pid>", methods=["PUT"])
def update_product(pid):
    data = request.get_json(force=True)
    conn = get_db()
    existing = conn.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
    if not existing:
        conn.close()
        return jsonify({"error": "not found"}), 404
    merged = {**dict(existing), **data}
    conn.execute(
        "UPDATE products SET name=?, sku=?, category=?, stock=?, price=?, low_threshold=?, critical_threshold=? WHERE id=?",
        (
            merged["name"], merged["sku"], merged["category"], merged["stock"],
            merged["price"], merged["low_threshold"], merged["critical_threshold"], pid,
        ),
    )
    conn.commit()
    row = conn.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
    conn.close()
    return jsonify(row_to_product(row))


@app.route("/api/products/<int:pid>", methods=["DELETE"])
def delete_product(pid):
    conn = get_db()
    conn.execute("DELETE FROM products WHERE id=?", (pid,))
    conn.commit()
    conn.close()
    return jsonify({"deleted": pid})


# ---------- Suppliers CRUD ----------

@app.route("/api/suppliers", methods=["GET"])
def get_suppliers():
    conn = get_db()
    rows = [dict(r) for r in conn.execute("SELECT * FROM suppliers ORDER BY id")]
    conn.close()
    return jsonify(rows)


@app.route("/api/suppliers", methods=["POST"])
def add_supplier():
    data = request.get_json(force=True)
    conn = get_db()
    cur = conn.execute(
        "INSERT INTO suppliers (name, contact, category, lead_time_days, rating, status) VALUES (?,?,?,?,?,?)",
        (
            data.get("name"), data.get("contact"), data.get("category"),
            data.get("lead_time_days", 0), data.get("rating", 0), data.get("status", "Active"),
        ),
    )
    conn.commit()
    new_id = cur.lastrowid
    row = dict(conn.execute("SELECT * FROM suppliers WHERE id=?", (new_id,)).fetchone())
    conn.close()
    return jsonify(row), 201


@app.route("/api/suppliers/<int:sid>", methods=["PUT"])
def update_supplier(sid):
    data = request.get_json(force=True)
    conn = get_db()
    existing = conn.execute("SELECT * FROM suppliers WHERE id=?", (sid,)).fetchone()
    if not existing:
        conn.close()
        return jsonify({"error": "not found"}), 404
    merged = {**dict(existing), **data}
    conn.execute(
        "UPDATE suppliers SET name=?, contact=?, category=?, lead_time_days=?, rating=?, status=? WHERE id=?",
        (
            merged["name"], merged["contact"], merged["category"],
            merged["lead_time_days"], merged["rating"], merged["status"], sid,
        ),
    )
    conn.commit()
    row = dict(conn.execute("SELECT * FROM suppliers WHERE id=?", (sid,)).fetchone())
    conn.close()
    return jsonify(row)


@app.route("/api/suppliers/<int:sid>", methods=["DELETE"])
def delete_supplier(sid):
    conn = get_db()
    conn.execute("DELETE FROM suppliers WHERE id=?", (sid,))
    conn.commit()
    conn.close()
    return jsonify({"deleted": sid})


# ---------- Sales CRUD ----------

@app.route("/api/sales", methods=["GET"])
def get_sales():
    conn = get_db()
    rows = [dict(r) for r in conn.execute("SELECT * FROM sales ORDER BY id DESC")]
    conn.close()
    return jsonify(rows)


@app.route("/api/sales", methods=["POST"])
def add_sale():
    data = request.get_json(force=True)
    conn = get_db()
    cur = conn.execute(
        "INSERT INTO sales (order_code, product, customer, qty, revenue, sale_date, status) VALUES (?,?,?,?,?,?,?)",
        (
            data.get("order_code"), data.get("product"), data.get("customer"),
            data.get("qty", 0), data.get("revenue", 0), data.get("sale_date"),
            data.get("status", "Pending"),
        ),
    )
    conn.commit()
    new_id = cur.lastrowid
    row = dict(conn.execute("SELECT * FROM sales WHERE id=?", (new_id,)).fetchone())
    conn.close()
    return jsonify(row), 201


@app.route("/api/sales/<int:said>", methods=["PUT"])
def update_sale(said):
    data = request.get_json(force=True)
    conn = get_db()
    existing = conn.execute("SELECT * FROM sales WHERE id=?", (said,)).fetchone()
    if not existing:
        conn.close()
        return jsonify({"error": "not found"}), 404
    merged = {**dict(existing), **data}
    conn.execute(
        "UPDATE sales SET order_code=?, product=?, customer=?, qty=?, revenue=?, sale_date=?, status=? WHERE id=?",
        (
            merged["order_code"], merged["product"], merged["customer"], merged["qty"],
            merged["revenue"], merged["sale_date"], merged["status"], said,
        ),
    )
    conn.commit()
    row = dict(conn.execute("SELECT * FROM sales WHERE id=?", (said,)).fetchone())
    conn.close()
    return jsonify(row)


@app.route("/api/sales/<int:said>", methods=["DELETE"])
def delete_sale(said):
    conn = get_db()
    conn.execute("DELETE FROM sales WHERE id=?", (said,))
    conn.commit()
    conn.close()
    return jsonify({"deleted": said})


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
